export class MerchantModel {
    public merchantId: number;
    public merchantFirstName: string;
    public merchantLastName: string;
    public merchantEmail: string;
    public merchantPassword: string;
    public merchantContact: string;
    public isMerchantActivated: boolean;

  
}



import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { MerchantDetailsComponent } from './merchant-details/merchant-details.component';
import { InventoryDetailsComponent } from './inventory-details/inventory-details.component';
import { CommonModule } from '@angular/common';

const routes: Routes = [
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: 'customerdetails', component: CustomerDetailsComponent},
  { path: 'merchantdetails', component: MerchantDetailsComponent },
  { path: 'inventorydetails', component: InventoryDetailsComponent },
  { path: '**', redirectTo: '', pathMatch: 'full'}
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }

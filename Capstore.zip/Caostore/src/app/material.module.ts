import { NgModule } from '@angular/core';
import {MatButtonModule, MatSidenav, MatNavList, MatSidenavContent, MatSidenavContainer, MatToolbarModule } from '@angular/material';
import {MatMenuModule} from '@angular/material/menu';
import {MatIconModule} from '@angular/material/icon';

import {MatListModule} from '@angular/material/list';

@NgModule({
  imports: [
    MatButtonModule,
    MatMenuModule,MatIconModule,MatToolbarModule,
    MatListModule
  ],
  exports:[
    MatButtonModule,MatMenuModule,MatIconModule,MatToolbarModule,
    
    MatListModule
  ]
})
export class MaterialModule { }

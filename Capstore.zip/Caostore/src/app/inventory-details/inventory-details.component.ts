import { Component, OnInit } from '@angular/core';
import { InventoryModel } from '../model/inventory';

import { CommonAdminService } from '../service/common-admin.service';

@Component({
  selector: 'app-inventory-details',
  templateUrl: './inventory-details.component.html',
  styleUrls: ['./inventory-details.component.css']
})
export class InventoryDetailsComponent implements OnInit {
  inventoryArr: InventoryModel[];

  constructor(private service: CommonAdminService) {
    this.inventoryArr = [];
  
  }

  ngOnInit() {
    
    this.service.getInventoryDetails().subscribe(data => {
      this.inventoryArr = data;
    });
   
  }

}

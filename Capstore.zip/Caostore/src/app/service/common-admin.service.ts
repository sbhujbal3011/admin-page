import { Injectable } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { MerchantModel } from '../model/merchant';
import { InventoryModel } from '../model/inventory';
import { Router } from '@angular/router';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CommonAdminService {

  customerArr: CustomerModel[];
  //cutomerObj: CustomerModel;
  merchantArr: MerchantModel[]
  inventoryArr: InventoryModel[];

  constructor(private routes: Router,private http: HttpClient, ) {
    this.customerArr = [];
    this.inventoryArr = [];
    this.merchantArr=[];
    
  }
  baseHref = "http://localhost:8888";


getCustomerDetails(){
  // this.http.get('http://localhost:8888/customerdetails').subscribe(data => {
    //console.log(data);
    return this.http.get<CustomerModel[]>(this.baseHref + "/customerdetails");
  };
 getMerchantDetails(){
 // this.http.get('http://localhost:8888/merchantdetails').subscribe(data => {
   //console.log(data);
   return this.http.get<MerchantModel[]>(this.baseHref + "/merchantdetails");
 };

getInventoryDetails(){
  //this.http.get('http://localhost:8888/inventorydetails').subscribe(data => {
   //console.log(data);
   return this.http.get<InventoryModel[]>(this.baseHref + "/inventorydetails");
 };
}




